export { default } from "./Course";
